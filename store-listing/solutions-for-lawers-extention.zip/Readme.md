Installation Steps:

Open Chrome and navigate to chrome://extensions/
Enable "Developer mode" (toggle in the top-right corner)
Click "Load unpacked" and select your extension folder