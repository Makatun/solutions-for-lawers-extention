# Promotional Text Options

## Short Promotional Description (Limited to 132 characters)
Track Visa Bulletin changes automatically. Get instant notifications when priority dates move and see what's changed at a glance.

## Feature Bullets for Chrome Web Store

• Automatically monitors Visa Bulletin updates
• Detects and highlights changed dates
• Shows whether dates moved forward or backward
• Simple tab navigation for Final Action and Filing dates
• Badge notifications for new changes
• No account required, works right out of the box
